﻿/* ============================================================
   供应商管理系统 — 全局交互脚本
   ============================================================ */

document.addEventListener("DOMContentLoaded", function () {

  /* ---- 移动端侧边栏切换 ---- */
  var menuBtn = document.getElementById("mobileMenuBtn");
  var sidebar = document.getElementById("sidebar");
  if (menuBtn && sidebar) {
    menuBtn.addEventListener("click", function () {
      sidebar.classList.toggle("open");
    });
    document.querySelector(".main-wrapper").addEventListener("click", function () {
      if (sidebar.classList.contains("open")) {
        sidebar.classList.remove("open");
      }
    });
  }

  /* ---- 删除确认 ---- */
  document.querySelectorAll("[data-confirm]").forEach(function (el) {
    el.addEventListener("click", function (e) {
      var msg = this.getAttribute("data-confirm") || "确定要执行此操作吗？";
      if (!confirm(msg)) {
        e.preventDefault();
        e.stopPropagation();
      }
    });
  });

  /* ---- 表单提交防重复点击 ---- */
  document.querySelectorAll("form").forEach(function (form) {
    form.addEventListener("submit", function () {
      var submitBtn = form.querySelector("button[type='submit']");
      if (submitBtn) {
        submitBtn.disabled = true;
      }
    });
  });

  /* ---- Flash 消息自动消失 ---- */
  setTimeout(function () {
    document.querySelectorAll(".flash-messages .alert").forEach(function (alert) {
      alert.style.transition = "opacity 0.5s";
      alert.style.opacity = "0";
      setTimeout(function () { alert.remove(); }, 500);
    });
  }, 4000);

  /* ---- 图片点击放大 ---- */
  document.querySelectorAll("[data-image-full]").forEach(function (img) {
    img.addEventListener("click", function () {
      var overlay = document.createElement("div");
      overlay.className = "image-modal-overlay";
      var fullImg = document.createElement("img");
      fullImg.src = this.getAttribute("data-image-full");
      overlay.appendChild(fullImg);
      document.body.appendChild(overlay);
      overlay.addEventListener("click", function () { overlay.remove(); });
    });
  });

  /* ---- 文件上传预览 ---- */
  var uploadInputs = document.querySelectorAll("[data-upload-preview]");
  uploadInputs.forEach(function (input) {
    var previewContainer = document.getElementById(input.getAttribute("data-upload-preview"));
    if (!previewContainer) return;

    var dropZone = previewContainer.querySelector(".upload-zone");
    if (dropZone) {
      ["dragenter", "dragover"].forEach(function (evt) {
        dropZone.addEventListener(evt, function (e) {
          e.preventDefault();
          dropZone.classList.add("dragover");
        });
      });
      ["dragleave", "drop"].forEach(function (evt) {
        dropZone.addEventListener(evt, function (e) {
          e.preventDefault();
          dropZone.classList.remove("dragover");
        });
      });
      dropZone.addEventListener("drop", function (e) {
        input.files = e.dataTransfer.files;
        showUploadPreviews(input, previewContainer);
      });
    }

    input.addEventListener("change", function () {
      showUploadPreviews(input, previewContainer);
    });
  });

  function showUploadPreviews(input, container) {
    var fileCount = container.querySelector(".upload-file-count");
    if (fileCount) {
      fileCount.textContent = input.files.length + " 个文件已选择";
    }

    var previewList = container.querySelector(".upload-preview-list");
    if (!previewList) return;
    previewList.innerHTML = "";

    Array.from(input.files).forEach(function (file) {
      if (!file.type.startsWith("image/")) return;
      var reader = new FileReader();
      reader.onload = function (e) {
        var item = document.createElement("div");
        item.className = "preview-item";
        var img = document.createElement("img");
        img.src = e.target.result;
        item.appendChild(img);
        previewList.appendChild(item);
      };
      reader.readAsDataURL(file);
    });
  }
});
